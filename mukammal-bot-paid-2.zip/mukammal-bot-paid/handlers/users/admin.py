from aiogram import types
from loader import dp, bot
from keyboards.inline.categories_inline import categorys, share
from states.AddProduct import AddProduct1
from aiogram.dispatcher import FSMContext
from utils.db_api.database import send_ex
from aiogram.types import ReplyKeyboardRemove
from keyboards.inline.categories_inline import categorysdelete
import asyncio
from states.new import EditCalatog

@dp.message_handler(text="🛍Mahsulot qo'shish")
async def addpro(msg: types.Message):
    await msg.answer("Qaysi categoriya bo'yicha qo'shmoqchisiz? Tanlang!", reply_markup=categorys)



@dp.callback_query_handler(text='admin1', state=None)
async def qwewe(call: types.Message, state :FSMContext):
    await call.message.answer("<b>🔗 Yaxshi endi maxsulotni nomini kiriting...</b>", reply_markup=ReplyKeyboardRemove())
    await AddProduct1.product_name.set()
    # await cat.delete()


@dp.message_handler(state=AddProduct1.product_name)
async def add(msg : types.Message, state : FSMContext):
    productName = msg.text

    await state.update_data({
        "productName":productName
    })
    await msg.answer('<b>🖼 Endi menga mahsulotning rasmini yuboring..</b>')

    await AddProduct1.next()


@dp.message_handler(content_types='photo', state = AddProduct1.photo)
async def photo(msg: types.Message, state :FSMContext):
    if msg.photo:
        photo = msg.photo[-1]

        # PHOTO ID
        photo_id = photo.file_id
        print(photo_id)
        await state.update_data(
            {"photoID" :photo_id}
        )
        await msg.answer('<b>💲 Ajoyib endi mahsulotning NARXINI kiriting...</b>')
        await AddProduct1.next()
    else:
        await msg.answer('Ilitmos faqat rasm yuboring')


@dp.message_handler(state=AddProduct1.price)
async def test(msg: types.Message, state :FSMContext):
    price = msg.text
    if price.isdigit():
        await state.update_data({
            "price":price
        })
        await msg.answer("<b>ℹ️ Endi maxsulot haqida MALUMOT bering...</b>")
        await AddProduct1.next()
    else:
        await msg.answer("Narx faqat raqamlardan iborat bo'lishi kerak")


@dp.message_handler(state=AddProduct1.description)
async def desc(msg: types.Message, state:FSMContext):
    description = msg.text

    await state.update_data(
        {'description':description}
    )

    await msg.answer("Mahsulot qo'shildi va guruhda yuborildi!!")

    data = await state.get_data()
    name = data.get('productName')
    photo = data.get('photoID')
    price = data.get('price')
    desc = data.get('description')

    try:
        testproduct = send_ex("CREATE TABLE IF NOT EXISTS ForFace(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, photoID TEXT, price INTEGER, description TEXT)")
        addproduct = send_ex(f"INSERT INTO ForFace(name, photoID, price, description) VALUES('{name}', '{photo}', '{price}', '{desc}')")
    except Exception as err:
        print(err)
        print('ERROR :   ', err)

    
    await bot.send_photo(chat_id=msg.chat.id, photo=str(photo), caption=f"📝 Mahsulot nomi:   <b>{name}</b>\n\n💰 Mahsulotimiz narxi:   <b>{price}</b>\n\nℹ️ Mahsulot haqida malumot: <b>{desc}</b>")
    await state.finish()




@dp.message_handler(text='🔵 Statistika')
async def sts(msg: types.Message):
    users = send_ex("SELECT * FROM users")
    await msg.answer(f'Statistika buyicha barcha obunachilar soni:  {len(users)}')





@dp.message_handler(text="✏️ Katalogni o'zgartirish")
async def tqwer(msg: types.Message):
    # cat1 = send_ex("SELECT * FROM catalog ORDER BY name DESC LIMIT 1")
    # print(cat1)
    # await msg.answer(f"Hozirgi katalog: {str(cat1[0][0])}")
    await msg.answer('Uzgartirmoqchi bo\'lgan katalogni kiriting...')
    await EditCalatog.name.set()




@dp.message_handler(state=EditCalatog.name)
async def edit(msg: types.Message, state : FSMContext):
    catalog = msg.text
    try:
        c = send_ex("CREATE TABLE IF NOT EXISTS catalog(name TEXT, id PRIMARY KEY AUTOINCREMENT)")
        c1 = send_ex(f"INSERT INTO catalog(name) VALUES('{catalog}')")
        await msg.answer("Katalog o'zgardi!")

        await state.finish()
    except:
        await msg.answer("Katalog o'zgarmadi!")
        






@dp.message_handler(text="🔗Katalogni ko'rish")
async def catat(msg: types.Message):
    cat = send_ex("SELECT * FROM catalog ORDER BY ROWID DESC LIMIT 1")
    if cat:
        await msg.answer(f"Hozirgi katalog: {cat[0][0]}")
    else:
        await msg.answer("Katalog topilmadi!")





