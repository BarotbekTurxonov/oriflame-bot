from aiogram.dispatcher.filters.state import StatesGroup, State


class BuyProduct1(StatesGroup):
    name = State()
    phone = State()
    dostavka = State()


class BuyProduct2(StatesGroup):
    name = State()
    phone = State()
    dostavka = State()


class BuyProduct3(StatesGroup):
    name = State()
    phone = State()
    dostavka = State()



class BuyProduct4(StatesGroup):
    name = State()
    phone = State()
    dostavka = State()



class BuyProduct5(StatesGroup):
    name = State()
    phone = State()
    dostavka = State()


class BuyProduct6(StatesGroup):
    name = State()
    phone = State()
    dostavka = State()


class BuyProduct7(StatesGroup):
    name = State()
    phone = State()
    dostavka = State()



class BuyProduct8(StatesGroup):
    name = State()
    phone = State()
    dostavka = State()