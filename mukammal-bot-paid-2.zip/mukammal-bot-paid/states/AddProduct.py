from aiogram.dispatcher.filters.state import StatesGroup, State

class AddProduct1(StatesGroup):
    product_name = State()
    photo = State()
    price = State()
    description = State()



class AddProduct2(StatesGroup):
    product_name = State()
    photo = State()
    price = State()
    description = State()




class AddProduct3(StatesGroup):
    product_name = State()
    photo = State()
    price = State()
    description = State()


class AddProduct4(StatesGroup):
    product_name = State()
    photo = State()
    price = State()
    description = State()



class AddProduct5(StatesGroup):
    product_name = State()
    photo = State()
    price = State()
    description = State()



class AddProduct6(StatesGroup):
    product_name = State()
    photo = State()
    price = State()
    description = State()




class AddProduct7(StatesGroup):
    product_name = State()
    photo = State()
    price = State()
    description = State()




class AddProduct8(StatesGroup):
    product_name = State()
    photo = State()
    price = State()
    description = State()
